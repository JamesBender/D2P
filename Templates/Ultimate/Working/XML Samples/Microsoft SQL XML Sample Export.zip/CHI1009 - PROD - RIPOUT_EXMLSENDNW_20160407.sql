SELECT FormatCode svFormatCode, CfgName svCfgName, CfgValue svCfgValue INTO dbo.U_EXMLSENDNW_SavePath FROM dbo.U_dsi_Configuration WITH (NOLOCK) WHERE FormatCode = 'EXMLSENDNW' AND CfgName LIKE '%Path';
IF OBJECT_ID('dsi_vwEXMLSENDNW_Export') IS NOT NULL DROP VIEW [dbo].[dsi_vwEXMLSENDNW_Export];
GO
IF OBJECT_ID('dsi_sp_BuildDriverTables_EXMLSENDNW') IS NOT NULL DROP PROCEDURE [dbo].[dsi_sp_BuildDriverTables_EXMLSENDNW];
GO
IF OBJECT_ID('dsi_sp_AfterCollect_EXMLSENDNW') IS NOT NULL DROP PROCEDURE [dbo].[dsi_sp_AfterCollect_EXMLSENDNW];
GO
IF OBJECT_ID('U_EXMLSENDNW_XML') IS NOT NULL DROP TABLE [dbo].[U_EXMLSENDNW_XML];
GO
IF OBJECT_ID('U_EXMLSENDNW_File') IS NOT NULL DROP TABLE [dbo].[U_EXMLSENDNW_File];
GO
IF OBJECT_ID('U_EXMLSENDNW_EEList') IS NOT NULL DROP TABLE [dbo].[U_EXMLSENDNW_EEList];
GO
IF OBJECT_ID('U_EXMLSENDNW_DrvTbl') IS NOT NULL DROP TABLE [dbo].[U_EXMLSENDNW_DrvTbl];
GO
DELETE [dbo].[U_dsi_Configuration] FROM [dbo].[U_dsi_Configuration] WHERE FormatCode = 'EXMLSENDNW';
DELETE [dbo].[AscExp] FROM [dbo].[AscExp] WHERE expFormatCode = 'EXMLSENDNW';
DELETE [dbo].[AscDefH] FROM [dbo].[AscDefH] WHERE AdhFormatCode = 'EXMLSENDNW';
INSERT INTO [dbo].[AscDefH] (AdhAccrCodesUsed,AdhAggregateAtLevel,AdhAuditStaticFields,AdhChildTable,AdhClientTableList,AdhCustomDLLFileName,AdhDedCodesUsed,AdhDelimiter,AdhEarnCodesUsed,AdhEEIdentifier,AdhEndOfRecord,AdhEngine,AdhFileFormat,AdhFormatCode,AdhFormatName,AdhFundCodesUsed,AdhImportExport,AdhInputFormName,AdhIsAuditFormat,AdhIsSQLExport,AdhModifyStamp,AdhOutputMediaType,AdhPreProcessSQL,AdhRecordSize,AdhSortBy,AdhSysFormat,AdhSystemID,AdhTaxCodesUsed,AdhYearStartFixedDate,AdhYearStartOption,AdhRespectZeroPayRate,AdhCreateTClockBatches,AdhThirdPartyPay) VALUES ('N','C','Y','0',NULL,NULL,'N',NULL,'N',NULL,'013010','EMPEXPORT','SDF','EXMLSENDNW','Send Word Now XML Export (XML)','N','E','FORM_EMPEXPORT','N','C','9WM8F90000K0','D','dbo.dsi_sp_SwitchBox_v2','500','S','N','EXMLSENDNWZ0','N',NULL,'C','N',NULL,'N');
INSERT INTO [dbo].[AscExp] (expAscFileName,expAsOfDate,expCOID,expCOIDAllCompanies,expCOIDList,expDateOrPerControl,expDateTimeRangeEnd,expDateTimeRangeStart,expDesc,expEndPerControl,expEngine,expExportCode,expExported,expFormatCode,expGLCodeTypes,expGLCodeTypesAll,expGroupBy,expLastEndPerControl,expLastPayDate,expLastPeriodEndDate,expLastStartPerControl,expNoOfRecords,expSelectByField,expSelectByList,expStartPerControl,expSystemID,expTaxCalcGroupID,expUser,expIEXSystemID) VALUES ('Hardcoded FileName',NULL,NULL,NULL,'XAX4W,BQ2W6,XAWNI,XAX6F,XAX1L',NULL,NULL,NULL,'Send Word Now XML Export','201602299','EMPEXPORT','ONDEMAND','Feb 29 2016  2:54PM','EXMLSENDNW',NULL,NULL,NULL,'201602299','Feb 29 2016 12:00AM','Dec 30 1899 12:00AM','197101011','607','','','197101011','B1M6B90010K0',NULL,'KBROOME',NULL);
INSERT INTO [dbo].[AscExp] (expAscFileName,expAsOfDate,expCOID,expCOIDAllCompanies,expCOIDList,expDateOrPerControl,expDateTimeRangeEnd,expDateTimeRangeStart,expDesc,expEndPerControl,expEngine,expExportCode,expExported,expFormatCode,expGLCodeTypes,expGLCodeTypesAll,expGroupBy,expLastEndPerControl,expLastPayDate,expLastPeriodEndDate,expLastStartPerControl,expNoOfRecords,expSelectByField,expSelectByList,expStartPerControl,expSystemID,expTaxCalcGroupID,expUser,expIEXSystemID) VALUES ('Hardcoded FileName',NULL,NULL,NULL,'XAX4W,BQ2W6,XAWNI,XAX6F,XAX1L',NULL,NULL,NULL,'Scheduled Session Only','201604069','EMPEXPORT','SCHEDULED','Jul 13 2015 12:00AM','EXMLSENDNW',NULL,NULL,NULL,'201604069','Jul 14 2015 12:00AM','Dec 30 1899 12:00AM','201603301','1','','','201603301','APQGCQ0000K0',NULL,'ULTI_CBOE',NULL);
INSERT INTO [dbo].[U_dsi_Configuration] (FormatCode,CfgName,CfgType,CfgValue) VALUES ('EXMLSENDNW','EEList','V','Y');
INSERT INTO [dbo].[U_dsi_Configuration] (FormatCode,CfgName,CfgType,CfgValue) VALUES ('EXMLSENDNW','ExportPath','V','\\us.saas\n0\data_exchange\CHI1009\Exports\');
INSERT INTO [dbo].[U_dsi_Configuration] (FormatCode,CfgName,CfgType,CfgValue) VALUES ('EXMLSENDNW','MultFile','V','Y');
INSERT INTO [dbo].[U_dsi_Configuration] (FormatCode,CfgName,CfgType,CfgValue) VALUES ('EXMLSENDNW','OverrideCount','V','612');
INSERT INTO [dbo].[U_dsi_Configuration] (FormatCode,CfgName,CfgType,CfgValue) VALUES ('EXMLSENDNW','Testing','V','N');
INSERT INTO [dbo].[U_dsi_Configuration] (FormatCode,CfgName,CfgType,CfgValue) VALUES ('EXMLSENDNW','TestPath','V','\\us.saas\n1\Public\10583\Exports\SendWordNow\');
INSERT INTO [dbo].[U_dsi_Configuration] (FormatCode,CfgName,CfgType,CfgValue) VALUES ('EXMLSENDNW','UDESPath','V','\\us.saas\n0\data_exchange\CHI1009\Exports\');
INSERT INTO [dbo].[U_dsi_Configuration] (FormatCode,CfgName,CfgType,CfgValue) VALUES ('EXMLSENDNW','UseFileName','V','N');
GO
UPDATE dbo.U_dsi_Configuration SET CfgValue = svCfgValue FROM dbo.U_EXMLSENDNW_SavePath WHERE CfgName = svCfgName AND FormatCode = svFormatCode;
IF OBJECT_ID('U_EXMLSENDNW_SavePath') IS NOT NULL DROP TABLE [dbo].[U_EXMLSENDNW_SavePath];
GO
IF OBJECT_ID('U_EXMLSENDNW_DrvTbl') IS NULL
CREATE TABLE [dbo].[U_EXMLSENDNW_DrvTbl] (
    [drvEmpNo] varchar(9) NULL,
    [drvNameFirst] varchar(100) NULL,
    [drvNameLast] varchar(100) NULL,
    [drvNameMiddle] varchar(1) NULL,
    [drvDepartment] varchar(25) NULL,
    [drvJobTitle] varchar(30) NULL,
    [drvDivision] varchar(25) NULL,
    [drvWorkPhoneBusinessCountry] varchar(1) NULL,
    [drvWorkPhoneBusinessNumber] varchar(10) NULL,
    [drvWorkPhoneBusinessExt] varchar(5) NULL,
    [drvCELPhoneCountryPrefix] varchar(10) NULL,
    [drvCELPhoneNumber] varchar(50) NULL,
    [drvCELPhoneExtension] varchar(10) NULL,
    [drvPhoneHomeCountry] varchar(1) NULL,
    [drvPhoneHomeNumber] varchar(50) NULL,
    [drvAddressEmail] varchar(50) NULL,
    [drvAddressEmailAlternate] varchar(50) NULL,
    [drvEEID] varchar(12) NULL,
    [drvCOID] varchar(5) NULL
);
IF OBJECT_ID('U_EXMLSENDNW_EEList') IS NULL
CREATE TABLE [dbo].[U_EXMLSENDNW_EEList] (
    [xCOID] char(5) NULL,
    [xEEID] char(12) NULL
);
IF OBJECT_ID('U_EXMLSENDNW_File') IS NULL
CREATE TABLE [dbo].[U_EXMLSENDNW_File] (
    [RecordSet] char(3) NOT NULL,
    [InitialSort] varchar(50) NOT NULL,
    [SubSort] varchar(50) NOT NULL,
    [SubSort2] varchar(50) NULL,
    [SubSort3] varchar(50) NULL,
    [Data] char(500) NULL
);
IF OBJECT_ID('U_EXMLSENDNW_XML') IS NULL
CREATE TABLE [dbo].[U_EXMLSENDNW_XML] (
    [XMLOUT] xml(max) NULL
);
GO
CREATE PROCEDURE [dbo].[dsi_sp_AfterCollect_EXMLSENDNW]
AS
/**********************************************************************************
Client: Chicago Board Options Exchange, Incorporated

Created By: Tanya Leonce
Business Analyst: Sandy Lacy
Create Date: 07/10/2015
PSA Request Number: SR-2014-00052836

Custom BCP Statement for XML File

Revision History
----------------
Update By            Date            Request Num                Desc
XXXX                 XX/XX/15        SR-2015-000XXXXX           Added 1234

SELECT * FROM dbo.U_dsi_Configuration WHERE FormatCode = 'EXMLSENDNW';
SELECT * FROM dbo.U_dsi_SqlClauses WHERE FormatCode = 'EXMLSENDNW';
SELECT * FROM dbo.U_dsi_Parameters WHERE FormatCode = 'EXMLSENDNW';
SELECT * FROM dbo.AscExp WHERE ExpFormatCode = 'EXMLSENDNW';

Execute Export
--------------
EXEC dbo.dsi_sp_TestSwitchbox_v2 'EXMLSENDNW', 'ONDEMAND';
EXEC dbo.dsi_sp_TestSwitchbox_v2 'EXMLSENDNW', 'SCHEDULED';
**********************************************************************************/
BEGIN

    -- Declare variables
    DECLARE @FormatCode        VARCHAR(10)
            ,@sCmd            VARCHAR(1000)
            ,@ExportPath    VARCHAR(500)
            ,@FileName        VARCHAR(100)
            ,@sXML            VARCHAR(100);

    -- Set variables
    SET @FormatCode = 'EXMLSENDNW';
    SET @ExportPath = dbo.dsi_fnVariable(@FormatCode,'ExportPath');
    SET @FileName = (SELECT ExportFile FROM dbo.U_dsi_Parameters (NOLOCK) WHERE FormatCode = 'EXMLSENDNW');
    SET @sXML = '<?xml version=""1.0""?>';

    --=====================================
    -- Generate XML File via Custom BCP
    --=====================================
    SELECT @sCmd = 'BCP "SELECT ''' + @sXML + ''' + CONVERT(VARCHAR(MAX),XMLOUT) FROM '+ RTRIM(DB_NAME()) + '.dbo.U_EXMLSENDNW_XML WITH (NOLOCK) " QueryOut "' + @ExportPath + @FileName +'"' +
                  ' -S"' + rtrim(@@SERVERNAME) + '" -T -c -t';

    PRINT 'Custom BCP: '+ @sCmd;

    EXEC master.dbo.xp_cmdshell @sCmd, NO_OUTPUT;

END
GO
CREATE PROCEDURE [dbo].[dsi_sp_BuildDriverTables_EXMLSENDNW]
    @systemid CHAR(12)
AS
/**********************************************************************************
Client: Chicago Board Options Exchange, Incorporated

Created By: Tanya Leonce
Business Analyst: Sandy Lacy
Create Date: 07/10/2015
PSA Request Number: SR-2014-00052836

Purpose: Send Word Now XML Export
Execute Export: dsi_sp_testswitchbox 'EXMLSENDNW', 'SCHEDULED'

Revision History
----------------
Update By            Date            Request Num                Desc
XXXX                 XX/XX/15        SR-2015-000XXXXX           Added 1234

SELECT * FROM dbo.U_dsi_Configuration WHERE FormatCode = 'EXMLSENDNW';
SELECT * FROM dbo.U_dsi_SqlClauses WHERE FormatCode = 'EXMLSENDNW';
SELECT * FROM dbo.U_dsi_Parameters WHERE FormatCode = 'EXMLSENDNW';
SELECT * FROM dbo.AscExp WHERE ExpFormatCode = 'EXMLSENDNW';

Execute Export
--------------
EXEC dbo.dsi_sp_TestSwitchbox_v2 'EXMLSENDNW', 'ONDEMAND';
EXEC dbo.dsi_sp_TestSwitchbox_v2 'EXMLSENDNW', 'SCHEDULED';

EXEC dbo._dsi_usp_ExportRipOut @FormatCode = 'EXMLSENDNW', @AllObjects = 'Y'
**********************************************************************************/
BEGIN

    --==========================================
    -- Declare variables
    --==========================================
    DECLARE  @FormatCode         VARCHAR(12)
            ,@ExportCode         VARCHAR(12)
            ,@StartDate          DATETIME
            ,@EndDate            DATETIME
            ,@StartPerControl    VARCHAR(9)
            ,@EndPerControl      VARCHAR(9)
            ,@FileName           VARCHAR(100)

    -- Declare dates from Parameter file
    SELECT
         @StartPerControl = StartPerControl
        ,@EndPerControl   = EndPerControl
        ,@StartDate       = CAST(LEFT(StartPerControl,8) AS DATETIME)
        ,@EndDate         = DATEADD(SS,-1,DATEADD(DD,1,LEFT(EndPerControl,8)))
        ,@FormatCode      = FormatCode
        ,@ExportCode      = ExportCode
    FROM dbo.U_dsi_Parameters WITH (NOLOCK)
    WHERE FormatCode = 'EXMLSENDNW';

    -- Set @FileName
    SET @FileName = 'writing_request_' + REPLACE(CONVERT(CHAR(10),GETDATE(),101),'/',SPACE(0)) + REPLACE(CONVERT(CHAR(8),GETDATE(),108),':',SPACE(0)) + '.xml'

    PRINT 'Start Date: ' + CONVERT(VARCHAR(26),@StartDate,100);
    PRINT 'End Date:  ' + CONVERT(VARCHAR(26),@EndDate,100);

    --==========================================
    -- Clean EE List
    --==========================================

    -- Cleans EE List of terms where EE active in another company (transfer), or active in more than one company
    DELETE FROM dbo.U_EXMLSENDNW_EEList WHERE xCoID <> dbo.dsi_BDM_fn_GetCurrentCoID(xEEID);

    -- Remove Terminated Employees
    DELETE FROM dbo.U_EXMLSENDNW_EEList
    FROM dbo.U_EXMLSENDNW_EEList WITH (NOLOCK)
    JOIN dbo.EmpComp WITH (NOLOCK)
        ON EecEEID = xEEID
        AND EecCoID = xCOID
        AND EecEmplStatus = 'T';

    --==========================================
    -- Build Employee Data and the driver tables
    --==========================================

    ------------------
    -- DETAIL RECORD
    ------------------
    IF object_id('U_EXMLSENDNW_DrvTbl') IS NOT NULL
        DROP TABLE dbo.U_EXMLSENDNW_DrvTbl
    SELECT DISTINCT drvEmpNo = RTRIM(EecEmpNo)
        ,drvNameFirst = RTRIM(EepNameFirst)
        ,drvNameLast = RTRIM(EepNameLast)
        ,drvNameMiddle = LEFT(EepNameMiddle,1)
        ,drvDepartment = RTRIM(O1.OrgDesc)
        ,drvJobTitle = RTRIM(EecJobtitle)
        ,drvDivision = RTRIM(O2.OrgDesc)
        ,drvWorkPhoneBusinessCountry = CASE WHEN RTRIM(EecPhoneBusinessCountry) = 'USA' THEN '1' END
        ,drvWorkPhoneBusinessNumber = RTRIM(EecPhoneBusinessNumber)
        ,drvWorkPhoneBusinessExt = RTRIM(EecPhoneBusinessExt)
        ,drvCELPhoneCountryPrefix = RTRIM(efoPhoneCountryPrefix)
        ,drvCELPhoneNumber = RTRIM(efoPhoneNumber)
        ,drvCELPhoneExtension = RTRIM(efoPhoneExtension)
        ,drvPhoneHomeCountry = CASE WHEN RTRIM(EepPhoneHomeCountry) = 'USA' THEN '1' END
        ,drvPhoneHomeNumber = RTRIM(EepPhoneHomeNumber)
        ,drvAddressEmail = RTRIM(EepAddressEmail)
        ,drvAddressEmailAlternate = RTRIM(EepAddressEmailAlternate)
        ,drvEEID = RTRIM(xEEID)
        ,drvCOID = RTRIM(xCOID)
    INTO dbo.U_EXMLSENDNW_DrvTbl
    FROM dbo.U_EXMLSENDNW_EELIST WITH (NOLOCK)
    JOIN dbo.EmpComp WITH (NOLOCK)
        ON EecEEID = xEEID
        AND EecCoID = xCOID
    JOIN dbo.EmpPers WITH (NOLOCK)
        ON eepEEID = xEEID
    LEFT JOIN dbo.OrgLevel O1 WITH (NOLOCK)
        ON O1.OrgCode = EecOrgLvl1
        AND O1.OrgLvl = '1'
    LEFT JOIN dbo.OrgLevel O2 WITH (NOLOCK)
        ON O2.OrgCode = EecOrgLvl2
        AND O2.OrgLvl = '2'
    LEFT JOIN (
        SELECT DISTINCT efoEEID, efoPhoneCountryPrefix, efoPhoneNumber, efoPhoneExtension
            ,RowNo = ROW_NUMBER() OVER (PARTITION BY efoEEID ORDER BY AuditKey DESC, efoPhoneNumber)
        FROM dbo.EmpMPhon WITH (NOLOCK)
        WHERE efoPhoneType = 'CEL'
    ) EmpMPhon
        ON efoEEID = xEEID
        AND RowNo = 1;

     --==========================================
    -- Build XML / Load For Custom BCP
    --==========================================

    -- Create Table for BCP Export
    IF OBJECT_ID('U_EXMLSENDNW_XML') IS NOT NULL
        DROP TABLE dbo.U_EXMLSENDNW_XML
    CREATE TABLE dbo.U_EXMLSENDNW_XML (
        XMLOUT XML
    );

    ------------------
    -- Build XML
    ------------------
    DECLARE @XML XML, @XMLOUT VARCHAR(MAX)

    SELECT @XML = (
        /***** Root Node Name: "batchContactList" *****/
        /***** Path Node Name: "contact" *****/
        SELECT
            "@contactID" = drvEmpNo
            ,"@action" = 'AddOrModify'
            ,"contactFieldFirstName/@name" = 'FirstName'
            ,contactFieldFirstName = drvNameFirst
            ,"contactFieldLastName/@name" = 'LastName'
            ,contactFieldLastName = drvNameLast
            ,"contactFieldMiddleName/@name" = 'MiddleName'
            ,contactFieldMiddleName = drvNameMiddle
            ,"contactFieldDept/@name" = 'CustomField'
            ,"contactFieldDept/@customName" = 'Department'
            ,contactFieldDept = drvDepartment
            ,"contactFieldDivision/@name" = 'CustomField'
            ,"contactFieldDivision/@customName" = 'Division'
            ,contactFieldDivision = drvDivision
            ,"contactPointList" = (    /***** Node Name: "contactPoint" *****/
                SELECT
                    "@type" = CASE
                                    WHEN Label = 'SMS' THEN 'TextMessage'
                                    WHEN Label LIKE '%Email%' THEN 'Email'
                                    ELSE 'Voice'
                              END
                    ,"contactPointFieldLabel/@name" = 'Label'
                    ,contactPointFieldLabel = Label
                    ,"contactPointFieldCountryCode/@name" = 'CountryCode'
                    ,contactPointFieldCountryCode = CountryCode
                    ,"contactPointFieldNumber/@name" = 'Number'
                    ,contactPointFieldNumber = CASE WHEN Label = 'SMS' THEN Number + '@sms.sendwordnow.com' ELSE Number END
                    ,"contactPointFieldExtension/@name" = 'Extension'
                    ,contactPointFieldExtension = Extension
                    ,"contactPointFieldCascadeOrder/@name" = 'CascadeOrder'
                    ,contactPointFieldCascadeOrder = CascadeOrder
                    ,"contactPointFieldEmail/@name" = 'Address'
                    ,contactPointFieldEmail = EmailAddress
                    ,"contactPointFieldCarrier/@name" = 'Carrier'
                    ,contactPointFieldCarrier = CASE WHEN Label = 'SMS' AND ISNULL(Number,'') <> '' THEN 'SWN Global SMS' END
                FROM (
                    -- Cell Phone Number
                    SELECT DISTINCT    drvEEID, drvEmpNo
                        ,Label = 'Cell Phone'
                        ,CountryCode = drvCELPhoneCountryPrefix
                        ,Number = drvCELPhoneNumber
                        ,Extension = drvCELPhoneExtension
                        ,CascadeOrder = '1'
                        ,EmailAddress = ''
                    FROM dbo.U_EXMLSENDNW_DrvTbl
                    WHERE ISNULL(drvCELPhoneNumber,'') <> ''

                    UNION ALL

                    -- Home Phone Number
                    SELECT DISTINCT    drvEEID, drvEmpNo
                        ,Label = 'Home Phone'
                        ,CountryCode = drvPhoneHomeCountry
                        ,Number = drvPhoneHomeNumber
                        ,Extension = ''
                        ,CascadeOrder = '2'
                        ,EmailAddress = ''
                    FROM dbo.U_EXMLSENDNW_DrvTbl
                    WHERE ISNULL(drvPhoneHomeNumber,'') <> ''

                    UNION ALL

                    -- Work Phone Number
                    SELECT DISTINCT    drvEEID, drvEmpNo
                        ,Label = 'Work Phone'
                        ,CountryCode = drvWorkPhoneBusinessCountry
                        ,Number = drvWorkPhoneBusinessNumber
                        ,Extension = drvWorkPhoneBusinessExt
                        ,CascadeOrder = '3'
                        ,EmailAddress = ''
                    FROM dbo.U_EXMLSENDNW_DrvTbl
                    WHERE ISNULL(drvWorkPhoneBusinessNumber,'') <> ''

                    UNION ALL

                    -- Email Address
                    SELECT DISTINCT    drvEEID, drvEmpNo
                        ,Label = 'Work Email'
                        ,CountryCode = ''
                        ,Number = ''
                        ,Extension = ''
                        ,CascadeOrder = ''
                        ,EmailAddress = drvAddressEmail
                    FROM dbo.U_EXMLSENDNW_DrvTbl
                    WHERE ISNULL(drvAddressEmail,'') <> ''

                    UNION ALL

                    -- Alternate Email Address
                    SELECT DISTINCT    drvEEID, drvEmpNo
                        ,Label = 'Alternate Email'
                        ,CountryCode = ''
                        ,Number = ''
                        ,Extension = ''
                        ,CascadeOrder = ''
                        ,EmailAddress = drvAddressEmailAlternate
                    FROM dbo.U_EXMLSENDNW_DrvTbl
                    WHERE ISNULL(drvAddressEmailAlternate,'') <> ''

                    UNION ALL

                    -- SMS Text Message
                    SELECT DISTINCT    drvEEID, drvEmpNo
                        ,Label = 'SMS'
                        ,CountryCode = ''
                        ,Number = ISNULL(drvCELPhoneCountryPrefix,'') + drvCELPhoneNumber
                        ,Extension = ''
                        ,CascadeOrder = ''
                        ,EmailAddress = ''
                    FROM dbo.U_EXMLSENDNW_DrvTbl
                    WHERE ISNULL(drvCELPhoneNumber,'') <> ''
                ) Contacts
                WHERE Contacts.drvEEID = Employee.drvEEID
                FOR XML PATH('contactPoint'), TYPE
            )
        FROM dbo.U_EXMLSENDNW_DrvTbl Employee
        ORDER BY drvEEID
        FOR XML PATH('contact')
            ,ROOT('batchContactList')
            ,TYPE
    );

    -- Remove EMPTY Nodes
    SET @XML.modify('delete //*[not(node())]')
    SET @XML.modify('delete //*[not(node())]')

    -- Add NameSpaces
    ;WITH XMLNAMESPACES (
        'http://www.sendwordnow.com' AS xs
    )
    SELECT @XMLOUT = (
        SELECT "@version" = '1.0.2'
            ,(    /***** Node Name: "batchProcessingDirectives" *****/
                SELECT "accountID/@username" = CASE WHEN dbo.dsi_fnVariable('EXMLSENDNW','Testing') = 'Y' THEN 'CBOEtestxml' ELSE 'CBOEalert' END
                    ,"batchProcessingOption1/@name" = 'DeleteContactsNotInBatch'
                    ,"batchProcessingOption1/@value" = 'true'
                    ,"batchProcessingOption2/@name" = 'MergeContactsInBatch'
                    ,"batchProcessingOption2/@value" = 'true'
                    ,"batchProcessingOption3/@name" = 'BatchContinueOnContactError'
                    ,"batchProcessingOption3/@value" = 'true'
                    ,"batchProcessingOption4/@name" = 'BatchContinueOnGroupError'
                    ,"batchProcessingOption4/@value" = 'true'
                    ,"batchProcessingOption5/@name" = 'ReturnContactListWithUniqueIDs'
                    ,"batchProcessingOption5/@value" = 'true'
                FOR XML PATH('batchProcessingDirectives'), TYPE
            )
            ,@XML
        FOR XML PATH('contactBatch')
    )

    -- Fix "contactField" values
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactFieldFirstName','contactField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactFieldLastName','contactField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactFieldMiddleName','contactField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactFieldDept','contactField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactFieldDivision','contactField'));

    -- Fix "contactPointFieldLabel" values
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactPointFieldLabel','contactPointField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactPointFieldCountryCode','contactPointField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactPointFieldNumber','contactPointField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactPointFieldExtension','contactPointField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactPointFieldCascadeOrder','contactPointField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactPointFieldEmail','contactPointField'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'contactPointFieldCarrier','contactPointField'));

    -- Fix Header Node: contactBatch
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'<contactBatch xmlns:xs="http://www.sendwordnow.com" version="1.0.2">','<contactBatch xmlns="http://www.sendwordnow.com" version="1.0.2">'));

    -- Fix Header Node: batchProcessingDirectives
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'<batchProcessingDirectives xmlns:xs="http://www.sendwordnow.com">','<batchProcessingDirectives>'));

    -- Fix "batchProcessingOption" values
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'batchProcessingOption1','batchProcessingOption'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'batchProcessingOption2','batchProcessingOption'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'batchProcessingOption3','batchProcessingOption'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'batchProcessingOption4','batchProcessingOption'));
    SET @XMLOUT = (SELECT REPLACE(@XMLOUT,'batchProcessingOption5','batchProcessingOption'));

    -- Load Into Custom Table for BCP Export
    INSERT INTO dbo.U_EXMLSENDNW_XML (XMLOUT)
    VALUES (@XMLOUT)

    --=====================================================
    -- Update Record Count
    --=====================================================
    UPDATE dbo.U_dsi_Configuration
        SET CfgValue = ISNULL((SELECT COUNT(*) FROM dbo.U_EXMLSENDNW_DrvTbl WITH (NOLOCK)),'0')
    WHERE FormatCode = 'EXMLSENDNW' AND CfgName = 'OverrideCount';

    --=====================================================
    -- Set FileName: writing_request_MMDDYYYYHHMMSS.xml
    --=====================================================
    IF (dbo.dsi_fnVariable('EXMLSENDNW','UseFileName') = 'N')
        UPDATE dbo.U_dsi_Parameters
            SET ExportFile = @FileName
        WHERE FormatCode = 'EXMLSENDNW';

END
/*

-- View XML File from XML Table
SELECT * FROM dbo.U_EXMLSENDNW_XML (NOLOCK)

*/
GO
Create View dbo.dsi_vwEXMLSENDNW_Export as
                            select top 200000000 Data from dbo.U_EXMLSENDNW_File with (nolock)
                            order by substring(RecordSet,2,2), InitialSort